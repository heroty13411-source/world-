import React, { useContext, useEffect, useState } from 'react';
import Spinner from '@/components/elements/Spinner';
import useFlash from '@/plugins/useFlash';
import { Form, Formik } from 'formik';
import FlashMessageRender from '@/components/FlashMessageRender';
import MinecraftMapsRow from '@/components/server/maps/MinecraftMapsRow';
import tw from 'twin.macro';
import Field from '@/components/elements/Field';
import { object, string } from 'yup';
import getMinecraftMaps, { Context as ServerMinecraftMapsContext } from '@/api/swr/getMinecraftMaps';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import Pagination from '@/components/elements/Pagination';

interface Values {
    search: string;
}

const MinecraftMapsContainer = () => {
    const { page, setPage, searchFilter, setSearchFilter } = useContext(ServerMinecraftMapsContext);
    const { clearFlashes, clearAndAddHttpError } = useFlash();
    const { data: minecraftMaps, error, isValidating } = getMinecraftMaps();

    const submit = ({ search }: Values) => {
        clearFlashes('minecraftMaps');
        setSearchFilter(search);
    };

    useEffect(() => {
        if (!error) {
            clearFlashes('minecraftMaps');

            return;
        }

        clearAndAddHttpError({ error, key: 'minecraftMaps' });
    }, [ error ]);

    if (!minecraftMaps || (error && isValidating)) {
        return <Spinner size={'large'} centered/>;
    }

    return (
        <ServerContentBlock title={'Minecraft Maps'}>
            <FlashMessageRender byKey={'minecraftMaps'} css={tw`mb-4`}/>
            <Formik
                onSubmit={submit}
                initialValues={{
                    search: searchFilter,
                }}
                validationSchema={object().shape({
                    search: string().optional().min(1),
                })}
            >
                <Form css={tw`mb-4`}>
                    <Field
                        id={'search'}
                        name={'search'}
                        label={'Search'}
                        type={'text'}
                    />
                </Form>
            </Formik>
            <Pagination data={minecraftMaps} onPageSelect={setPage}>
                {({ items }) => (
                    !items.length ?
                        <p css={tw`text-center text-sm text-neutral-300`}>
                            {page > 1 ?
                                'Looks like we\'ve run out of Minecraft maps to show you, try going back a page.'
                                :
                                'It looks like there are no Minecraft maps matching search criteria.'
                            }
                        </p>
                        :
                        items.map((minecraftMap, index) => <MinecraftMapsRow
                            key={minecraftMap.id}
                            minecraftMap={minecraftMap}
                            css={index > 0 ? tw`mt-2` : undefined}
                        />)
                )}
            </Pagination>
        </ServerContentBlock>
    );
};

export default () => {
    const [ page, setPage ] = useState<number>(1);
    const [ searchFilter, setSearchFilter ] = useState<string>('');

    return (
        <ServerMinecraftMapsContext.Provider value={{ page, setPage, searchFilter, setSearchFilter }}>
            <MinecraftMapsContainer/>
        </ServerMinecraftMapsContext.Provider>
    );
};
