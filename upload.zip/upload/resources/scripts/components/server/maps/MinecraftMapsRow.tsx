import React, { useCallback, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faDownload } from '@fortawesome/free-solid-svg-icons';
import { format, formatDistanceToNow } from 'date-fns';
import tw from 'twin.macro';
import useFlash from '@/plugins/useFlash';
import GreyRowBox from '@/components/elements/GreyRowBox';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import { ServerContext } from '@/state/server';
import Select from '@/components/elements/Select';
import decompressFiles from '@/api/server/files/decompressFiles';
import http from '@/api/http';

interface Props {
    minecraftMap: any;
    className?: string;
}

export default ({ minecraftMap, className }: Props) => {
    const uuid = ServerContext.useStoreState(state => state.server.data!.uuid);
    const { clearAndAddHttpError, addFlash } = useFlash();
    let url = minecraftMap.files[0]?.downloadUrl;

    const updateSelectedFile = useCallback((v: React.ChangeEvent<HTMLSelectElement>) => {
        url = v.currentTarget.value;
    }, [ uuid, url ]);

    const installMap = () => {
        if (url === null || url === undefined) return;

    http.post(`/api/client/servers/${uuid}/files/pull`, { directory: '/', url: encodeURI(url) })
	.then(function () {
		addFlash({ type: 'success', key: 'minecraftMaps', message: 'File has been scheduled for downloading.' });
	})
	.catch(function (error) {
	    clearAndAddHttpError({ key: 'minecraftMaps', error });
	});
    };

    return (
        <GreyRowBox css={tw`flex-wrap md:flex-nowrap items-center`} className={className}>
            <div css={tw`flex items-center truncate w-full md:flex-1`}>
                <div css={tw`flex flex-col truncate`}>
                    <div css={tw`flex items-center text-sm mb-1`}>
                        <div css={tw`w-10 h-10 rounded-lg bg-white border-2 border-neutral-800 overflow-hidden hidden md:block`}>
                            <img css={tw`w-full h-full`} alt={minecraftMap.name} src={minecraftMap.logo.thumbnailUrl}/>
                        </div>
                        <a href={minecraftMap.websiteUrl} css={tw`ml-4 break-words truncate`}>
                            {minecraftMap.name}
                        </a>
                    </div>
                    <p css={tw`mt-1 md:mt-0 text-xs truncate`}>
                        {minecraftMap.categories.map((category: any, index: any) => (
                            <img css={index > 0 ? tw`ml-1 w-4 h-auto inline` : tw`w-4 h-auto inline`} key={category.categoryId} src={category.iconUrl} alt={category.name} title={category.name} />
                        ))}
                    </p>
                </div>
            </div>
            <div css={tw`flex-1 md:flex-none md:w-96 mt-4 md:mt-0 md:ml-8 md:text-center`}>
                <p css={tw`text-sm`}>
                    {minecraftMap.summary}
                </p>
            </div>
            <div css={tw`flex-1 md:flex-none md:w-48 mt-4 md:mt-0 md:ml-8 md:text-center`}>
                <p
                    title={format(new Date(minecraftMap.dateReleased), 'ddd, MMMM do, yyyy HH:mm:ss')}
                    css={tw`text-sm`}
                >
                    {formatDistanceToNow(new Date(minecraftMap.dateReleased), { includeSeconds: true, addSuffix: true })}
                </p>
                <p css={tw`text-2xs text-neutral-500 uppercase mt-1`}>Released</p>
            </div>
            <div css={tw`flex-1 md:flex-none md:w-48 mt-4 md:mt-0 md:ml-8 md:text-center`}>
                <Select
                    disabled={minecraftMap.files.length < 2}
                    onChange={updateSelectedFile}
                    defaultValue={minecraftMap.files[0]?.id}
                >
                    {minecraftMap.files.map((file: any) => (
                        <option key={file.id} value={file.downloadUrl}>{file.displayName}</option>
                    ))}
                </Select>
            </div>
            <div css={tw`mt-4 md:mt-0 ml-6`} style={{ marginRight: '-0.5rem' }}>
                <button
                    type={'button'}
                    aria-label={'Install'}
                    css={tw`block text-sm p-1 md:p-2 text-neutral-500 hover:text-neutral-100 transition-colors duration-150 mx-4`}
                    onClick={installMap}
                >
                    <FontAwesomeIcon icon={faDownload} />
                </button>
            </div>
        </GreyRowBox>
    );
};
