import useSWR from 'swr';
import http, { PaginatedResult } from '@/api/http';
import { createContext, useContext } from 'react';

interface ctx {
    page: number;
    setPage: (value: number | ((s: number) => number)) => void;
    searchFilter: string;
    setSearchFilter: (value: string | ((s: string) => string)) => void;
}

export const Context = createContext<ctx>({ page: 1, setPage: () => 1, searchFilter: '', setSearchFilter: () => '' });

export default () => {
    const { page, searchFilter } = useContext(Context);

    return useSWR<PaginatedResult<any>>([ 'server:minecraftMaps', page, searchFilter ], async () => {
        const { data } = await http.get('/api/client/curse', { params: { index: page - 1 + (page - 1) * 10, pageSize: 10, gameId: 432, searchFilter, sectionId: 17 }, timeout: 120000 });

        return ({
            items: (data.mods || []),
            pagination: { total: data.pagination.totalCount, count: data.pagination.resultCount, perPage: data.pagination.pageSize, currentPage: page, totalPages: data.pagination.totalCount / data.pagination.pageSize },
        });
    });
};
